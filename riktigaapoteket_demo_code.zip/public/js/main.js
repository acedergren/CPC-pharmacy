window.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const price = params.get('price') || '0';
  document.getElementById('price-label').textContent = price;
  document.getElementById('checkout-form').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.target;
    const data = {
      product: params.get('product') || 'Okänd produkt',
      price, name: form.name.value, email: form.email.value,
      cardNumber: form.cardNumber.value, expiry: form.expiry.value,
      cvv: form.cvv.value, address: form.address.value
    };
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const json = await res.json();
      document.getElementById('result').textContent = json.success
        ? '✅ Tack! Din beställning är mottagen.' : '❌ Något gick fel, försök igen.';
    } catch (err) {
      document.getElementById('result').textContent = `🚨 Serverfel: ${err.message}`;
    }
  });
});
